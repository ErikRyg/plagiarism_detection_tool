#include <stdio.h> 
#include <stdlib.h>
#include <time.h>
#include <math.h>


//Aufgabe 1
unsigned char primZahl(int zahl) {
	int i = 1; 
	int rest = 1;
	unsigned char istPrimzahl = 1;
	do{
	i++;
	rest = zahl%i;
	if(rest==0 || zahl == 1) {
	istPrimzahl = 0;
	}
	} while(rest != 0 && i <= zahl/i);

	return istPrimzahl;
}

//Aufgabe 1
void primZahlSpiel() {
	
	int zahl = 0;
	srand(time(NULL));
	zahl = rand() % 100 +1;
	printf("Zufaellig erzeugte Zahl: \n");	
	printf("%i \n",zahl);
	printf("Bitte antworten Sie mit [j] für ja oder [n] für nein, auf die Frage ob es sich um eine Primzahl handelt: \n");
	char antwort = getchar();
	//Soll die Enter Taste abfangen
	getchar();
	// Es soll ja nur mit j oder n geantwortet werden, somit eignet sich switch am besten!
	switch(antwort){
	case 'j':
	if(primZahl(zahl)) printf("Sehr gut!\n");
	else printf("Leider falsch \n");
	break;

	case 'n':
	if(primZahl(zahl)) printf("Leider falsch\n");
	else printf("Sehr gut! \n");
	break;

	default:
	printf("Ungueltige Eingabe! \n");
	break;
	}

}

//Aufgabe 2
void bachetscheSpiel() {
	int summe = 100;
	char spielerA, spielerB;
	int i = 0;
	int abzug = 0;
	printf("Kuerzel von Spieler 1 eingeben (ein Buchstabe):");
	spielerA = getchar();
	getchar();
	printf("\nKuerzel von Spieler 2 eingeben (ein Buchstabe):");
	spielerB = getchar();
	getchar();
	while(summe>0) {
	if(i == 0){
	printf("\n%c, bitte eine Zahl zwischen 1 und 10 eingeben: ",spielerA);
	scanf("%i", &abzug);
	while(abzug > 10 || abzug < 1) {
	printf("\nFehlerhafte Zahl. Bitte erneut eingeben:");
	scanf("%i", &abzug);
	}
	i++;
	} else {
	printf("\n%c, bitte eine Zahl zwischen 1 und 10 eingeben: ",spielerB);
	scanf("%i", &abzug);
	while(abzug > 10 || abzug < 1) {
	printf("\nFehlerhafte Zahl. Bitte erneut eingeben:");
	scanf("%i", &abzug);
	}
	i--;
	}
	summe -= abzug;
	printf("\nAktuelle Summe: %i", summe);
	}
	if(i == 1) printf("\nHerzlichen Glueckwunsch %c. Du hast gewonnen!", spielerA);
	else printf("\nHerzlichen Glueckwunsch %c. Du hast gewonnen!\n", spielerB);
}

//Aufgabe 3
void binToDec(int bin) {
	int dec = 0;
	int i = 1;
	if(bin > 0){
	dec += bin%10;
	bin = bin/10;
	} else if (bin == 0) printf("Die Dezimalzahl ist 0");  //Wenn bin Null ist dann ist die Dezimalzahl dazu auch null;
	else if(bin <0) printf("Falsche Eingabe");
	while(bin > 0) {
	dec += bin%10 *pow(2,i);
	bin = bin/10; 
	i++;
	}
	printf("\nDie Dezimalzahl ist: %i \n", dec); 
}

int main() {
	//Aufgabe 1
	//primZahlSpiel();
	//Aufgabe 2
	//bachetscheSpiel();
	//Aufgabe 3
	int zahl = 0;
	printf("\nBitte eine Binaerzahl eingeben: ");
	scanf("%i", &zahl);
	binToDec(zahl);
	
}

