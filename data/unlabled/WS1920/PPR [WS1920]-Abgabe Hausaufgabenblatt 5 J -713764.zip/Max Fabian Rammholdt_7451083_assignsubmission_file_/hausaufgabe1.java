 /* Aufgabe 1: Variablen

	a) float: Da Buspreise in Kommabeträgen gegeben werden, verwendet man eine Gleitkommazahl mit ausreichendem Wertebereich.
	
	b) int: Der Abstand Erde - Mond beträgt 384.400km. Folglich benötigt man ganze Zahlen, um den Abstand zu definieren. Der kleinstmögliche Datentyp, der 384.400 im 		Wertebereich hat, ist int.

	c)char: Bei der Eingabe in die Tastatur können auch Buchstaben eingegeben werden. Dementsprechend braucht man ein Unicodezeichen (char).

	d)byte: Byte ist der Datentyp mit dem kleinstmöglichen Wertebereich um die 6 unterschiedlichen Ausgangsmöglichkeiten darzustellen.


Aufgabe 1.2: 

	Im main string versucht das Programm auf die Variable "verdientesGeld" zuzugreifen, obwohl diese nur für die Methode "arbeiten" definiert ist.
	Außerdem will das Programm in der Methode "arbeiten" auf die Variable "Stundenlohn" zugreifen, obwohl diese nur für den main string definiert ist.*/

public class geldverdienen {
	public static double arbeiten(double anzahlStunden){
		double stundenlohn = 8.5;
		double verdientesGeld = anzahlStunden * stundenlohn;
		return verdientesGeld;
	}

	public static void main(String[]args){
		double kontostand = 0;
		kontostand += arbeiten(8.0);
		System.out.println (" Auf dem Konto befinden sich " + kontostand + " Euro.");
	}
}


/* Aufgabe 2: Funktionen

	1. public static int subtraktion(int a, int b){}
	2. public static boolean vergleich(int a, int b){} 
	3. public static float geldbetrag(float a){}
	4. public static double pi(double a){}


Aufgabe 3: Handsimulation

Zeile	start	anzahl	x	y	summe	z	mean	mittel	wert
15	5	0	-	-	-	-	-	-	-
16								0	
17									0
5(18)			5	0					
6(18)					5				
7(18)									
8(18)			-	-	-				
18									5
19		1							
5(20)			5	2					
6(20)					7				
7(20)									
8(20)			-	-	-				
20									7
21		2							
10(22)						7			
11(22)							3.5		
12(22)									
13(22)						-	-		
22								3.5	
23								-	-




Aufgabe 4: Note berechnen J*/

public class note{
	public static float notenberechnung(float x, float y){
		float z = (0.3f * x) + (0.7f * y);
		return z;
	}

	public static void main(String[]args){
		float uenote = Terminal.askFloat( "Bitte gib deine Uebungsnote ein: " );
		float knote = Terminal.askFloat( "Bitte gib deine Klausurnote ein: " );
		float endnote = notenberechnung(uenote, knote);
		System.out.println( "Deine Endnote lautet: "+endnote );
	}
}


/* Aufgabe 5: Doppelt fällt besser */

public class Duplette{

	public static double berechneRabattPreis(double grundpreis, int rabattProzent, int isXmas){
		int rabattReal = isXmas * rabattProzent;
		double preisRabattiert = grundpreis * (1 - rabattReal/100.0);
		return preisRabattiert;
	}


	public static void main(String[]args){
		int studentenrabattProzent = 50;	
		int mitarbeiterrabattProzent = 25;
		int externerabattProzent = 0;
		double preisGericht = Terminal.askFloat( "Was kostet das Essen ohne Abzug von Rabatten?" );
		int istWeihnachten = Terminal.askInt( "Ist heute Weihnachten? (Ja: 1, Nein: 0)" );
		double endpreisStudent = berechneRabattPreis(preisGericht, studentenrabattProzent, istWeihnachten);
		double endpreisMitarbeiter = berechneRabattPreis(preisGericht, mitarbeiterrabattProzent, istWeihnachten);		
		double endpreisExterne = berechneRabattPreis(preisGericht, externerabattProzent, istWeihnachten);

		System.out.println ( "Das macht " +endpreisStudent+ " Euro fuer Studenten." );
		System.out.println ( "Das macht " +endpreisMitarbeiter+ " Euro fuer Mitarbeiter." );
		System.out.println ( "Das macht " +endpreisExterne+ " Euro fuer Gaeste." );
	}
}

