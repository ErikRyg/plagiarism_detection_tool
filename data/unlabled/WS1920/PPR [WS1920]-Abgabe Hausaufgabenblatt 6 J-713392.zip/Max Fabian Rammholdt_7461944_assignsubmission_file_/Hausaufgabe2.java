/* Aufgabe 1: ExDuplicato */

public class Duplicato{
	
	public static int eingabe(){
		int y = Terminal.askInt( "Please enter a positive integer number: " );
		if (y < 0){
			Terminal.println( "A positive number was requested...");
			}
		Terminal.println( "Your choice was " +y);
		return y;
	}
	
	public static void main(String[] args){
		int a = 0;		
		int b = 0;	
		
		a = eingabe ();
		b = eingabe ();

		int c = a + b;
		Terminal.println ( "And the sum is " +c);
	}
}


/* Aufgabe 2: Variable

Zeile	dichte	gen	breite	laenge	a	b	c	hoehe	bed
6	-	-	-	-	-	-	-	-	-
7			3						
8				5.5					
9	50.12								
2(10)					3	5	50.12	undef	
3(10)		0							
4(10)									
5(10)		-			-	-	-		
10								0	
11								0	
12									0
13									
14	-		-	-				-	-



Aufgabe 3: */

public class Modulverwaltung{
	
	public static void main(String[] args){
		int eingabe;
		eingabe = Terminal.askInt( "[1] fuer Modulanmeldung \n[2] fuer Modulabmeldung \n[3] fuer angemeldete Module anzeigen \n" );

		switch(eingabe){
			
			case 1 : Terminal.println( "Du hast \"Modulanmeldung\" ausgewaehlt." );
				break;
			
			case 2 : Terminal.println( "Du hast \"Modulabmeldung\" ausgewaehlt." );
				break;

			case 3 : Terminal.println( "Du hast \"angemeldete Module anzeigen\" ausgewaehlt." );
				break;
			default: Terminal.println( "Das stand nicht zur Auswahl." );
			}
	}
}


/* Aufgabe 4: */

public class Countdownzaehler{

	public static int countdown(int start){
		for(int x = start; x >= 0; x -= 1){
		if( x < 1 ){
			break;
			}
		start = x;	
		Terminal.println( start+"\n");
		}
	Terminal.println( "Start!!!" );	
	return start;
	}

	public static void main(String[] args){
		int zahl = Terminal.askInt( "Gebe eine Zahl ein:" );
		countdown(zahl);
	}
}


/* Aufgabe 5: Gradiant */

public class Gradiant{
	
	public static double gradberechnung(double radiant){
		double grad = radiant*180/3.14159265359;
		return grad;
	}

	public static void main(String[] args){
		double bogenmaß = 0;	
		while( bogenmaß >=0 ){
			bogenmaß = Terminal.askDouble( "Bitte geben sie einen Winkel in Radiant ein:" );
			double winkel = gradberechnung(bogenmaß);
			Terminal.println( "Der Winkel betraegt "+winkel+" Grad." );
		}
	}
}


/* Aufgabe 6: Reihenfolge */

public class Reihenfolge{
	
	public static int folge(int beginn){
		int i = 0;		
		while(beginn > 0){		
			int rest = beginn % 3;
			i ++;
		
			if(rest <= 0){		
				beginn += 2;
				}
			else{				
				beginn -= 4;
				}
			System.out.println("die Zahl ist " +beginn );
		}
		
		System.out.println( "Es haben "+i+" Schritte stattgefunden." );
		return beginn;
	}	

	public static void main(String[] args){
		int start = Terminal.askInt( "Gib eine positive ganze Zahl ein: " );
		
		if(start > 1){
			folge(start);
			}
		else{
			System.out.println( "FEHLER" );
			}	
	}
}
