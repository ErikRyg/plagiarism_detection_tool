#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/
ListenElement* wurzel;
ListenElement* liste;
void createAbteilungsListen(ListenElement* pMitarbeiter)
{
	ListenElement* Arbeiterliste = malloc(sizeof(ListenElement));
	Arbeiterliste->pPerson = pMitarbeiter->pPerson->name;
	Arbeiterliste->pnext = NULL;
	
	liste = Arbeiterliste;
	wurzel = Arbeiterliste;
}

void appendElement(ListenElement* pMitarbeiter)
{
	ListenElement* neu = malloc(sizeof(ListenElement));
	neu->pPerson = pMitarbeiter->pPerson->name;
	neu->pnext = NULL;
	liste = wurzel;
	
	while(liste != NULL)
	{
		if(liste->pnext == NULL)
		{
			liste->pnext = neu;
			break;
		}
		else
		{
			liste = liste->pnext;
		}
	}
}

void buchstabenborder(ListenElement* pMitarbeiter)
{
	for (int i=65;i<91;i++)
	{
		createAbteilungsListen(pMitarbeiter);
		for(int j=0;j<50;j++)
		{
			if(pMitarbeiter[j].pPerson->name == i)
			{
				appendElement(pMitarbeiter[j].pPerson->name);
			}
		}
	}
}


/*---------------------------------------------------------*/

int main()
{
   srand( time(0) ); //initialisiert den zufallszahlengenerator
   // Abteilungen f�llen 
   Person* Mitarbeiter = malloc(50*sizeof(Person));
   if (!(Mitarbeiter)) exit (-1);
  	buchstabenborder(&Mitarbeiter);
   for(int i=0;i<50;i++)
   {
   	setRandName(Mitarbeiter[i].name);
   	Mitarbeiter[i].abteilung = Mitarbeiter[i].name[0];
   }
   
   for(int i=0;i<50;i++)
   {
   	printf("Name: %s     Abteilungen: %c \n", Mitarbeiter[i].name,Mitarbeiter[i].abteilung);
   }
   
   
   // Abteilungen ausgeben
   // Mitarbeiter k�ndigen oder in neue Abteilungen verschieben
   // Neue Abteilungen ausgeben
}
