#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{ // 12byte
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{ //16 Byte
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/
typedef struct liste { // 16 Byte
ListenElement* head;
unsigned int length;
}Liste;

// Array von Pointern, die auf Listen(-k�pfe) zeigen
Liste AbteilungenA_Z[26];  






/*---------------------------------------------------------*/

int main()
{
   srand( time(0) ); //initialisiert den zufallszahlengenerator

 // Abteilungen f�llen 
Person Mitarbeiter[50];
for(int i = 0; i<50; i++)
  {
   Person* P_Mi = (Mitarbeiter+sizeof(Person)*i); 
   setRandName(P_Mi );
   P_Mi->abteilung  = P_Mi->name[0];
   unsigned int Listenvar = (int)(P_Mi->name[0]-65);                                                                                  
   if(AbteilungenA_Z[Listenvar].length == 0)                                                                                      
     {
 
      AbteilungenA_Z[Listenvar].length++;
       ListenElement *(AbteilungenA_Z[Listenvar].head) = {P_Mi,0};
      }
   else 
  {
  ListenElement = {P_Mi, 0};
     for(;(AbteilungenA_Z +(*sizeof(Liste)))->head)->pnext) !=0; pnext = (AbteilungenA_Z +(*sizeof(Liste)))->head)->pnext) )
     {}   
   }


}


   // Abteilungen ausgeben
   // Mitarbeiter k�ndigen oder in neue Abteilungen verschieben
   // Neue Abteilungen ausgeben
}
