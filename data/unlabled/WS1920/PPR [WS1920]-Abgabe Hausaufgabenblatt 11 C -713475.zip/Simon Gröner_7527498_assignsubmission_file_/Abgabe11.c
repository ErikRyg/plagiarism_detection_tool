#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/


Person* Arbeiter_Neu(){
Person* p_Arbeiter=(Person*) malloc(1*sizeof(Person));
if(p_Arbeiter == 0 ){
exit(-1);
}
setRandName(p_Arbeiter->name);
p_Arbeiter->abteilung=p_Arbeiter->name[0];
return p_Arbeiter;
} 


void printArbeiter(Person* typ){

printf("Name:%sAbteilung:%c\n",typ->name,typ->abteilung);
}
 ListenElement*getelem(Person* typ){
ListenElement* Liste_Neu=(ListenElement*)malloc(1*sizeof(ListenElement));
if (Liste_Neu == 0){
exit(-1);
}
Liste_Neu->pPerson=typ;
Liste_Neu->pnext = 0;
return Liste_Neu;
} 
ListenElement* lastelement(ListenElement* pAnfang){
if(pAnfang==0)
return pAnfang;
else{ListenElement*p_list=pAnfang;
while(p_list->pnext!= 0)
p_list=p_list->pnext;
return p_list;
}
}
ListenElement*addtolist(ListenElement*pAnfang,ListenElement*Liste_Neu){
if(pAnfang){
ListenElement* pEnde = lastelement(pAnfang);
pEnde->pnext = Liste_Neu;
return pAnfang;
}
else{
Liste_Neu->pnext=0;
return Liste_Neu;
}
}
void getlist(ListenElement* pAnfang){
ListenElement* p_list = pAnfang;
while(p_list!= 0){
printArbeiter(p_list->pPerson);
p_list=p_list->pnext;
}
}


/*---------------------------------------------------------*/

int main()
{
   srand( time(0) );
int anzahlArbeiter=50;
ListenElement* abteilungen[26];
for( int i = 0; i < 26; i++ )
abteilungen[i]=0;
for(int i = 0; i < anzahlArbeiter; i++){
Person* p_Arbeiter = Arbeiter_Neu();
int aIndex = p_Arbeiter->name[0] - 'A';
abteilungen[aIndex] = addtolist( abteilungen[aIndex], getelem(p_Arbeiter));
}
 printf("PPrima Personal:\n");for( int i = 0; i < 26; i++ ){
 printf( "== Abteilung %c ==\n", i+'A' );
 getlist(abteilungen[i]);
}
printf( "\nFirmenumstrukturierung...\n");
int newworkcount= 20;
ListenElement*abteilungen_neu[5];
for( int i = 0; i < 5; i++ )
abteilungen_neu[i]=0;
for( int i = 0; i < 26; i++ ){
while(abteilungen[i]){
ListenElement* pArbeiter=abteilungen[i];
int neueAbteilung=1;
switch(pArbeiter->pPerson->name[1]){
case 'a':neueAbteilung=1;
break;
case 'e':neueAbteilung=2;
break;
case 'i':neueAbteilung=3;
break;
case 'o':neueAbteilung=4;
break;
case 'u':neueAbteilung=5;
break;
}
abteilungen[i]=pArbeiter->pnext;
pArbeiter->pnext=0;
pArbeiter->pPerson->abteilung=neueAbteilung+'1'-1;
if(newworkcount){
abteilungen_neu[neueAbteilung-1] = addtolist(abteilungen_neu[neueAbteilung-1],pArbeiter);
newworkcount--;
}
else{
printf("%s muss leider gekuendigt werden.\n",pArbeiter->pPerson->name);
free(pArbeiter->pPerson);
free(pArbeiter);
}
}
}
printf("\nPPrima Personal nach Umstrukturierung:\n");
for( int i = 0; i < 5; i++ ){
printf("== Abteilung %i ==\n", i+1);
getlist(abteilungen_neu[i]);
}
return 0;
}
