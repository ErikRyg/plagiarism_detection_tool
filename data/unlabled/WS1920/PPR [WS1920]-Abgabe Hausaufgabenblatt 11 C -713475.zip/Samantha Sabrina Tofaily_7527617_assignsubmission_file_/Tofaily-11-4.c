#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> 


typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;

struct ListenElement* pnext = NULL;
struct ListenElement* anfang = NULL;

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}


char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); 
  }
  pname[len] = '\0';
  pname[0] -= 32; 
}



Person* newperson()
{
  Person* NewEmployee = (Person*) malloc(1 * sizeof(Person));
  setRandName(NewEmployee->name);
  NewEmployee->abteilung = NewEmployee->name[0];
  return NewEmployee;
}

ListenElement* createlist(Person* p)
{
  ListenElement* neulist = (ListenElement*) malloc(1*sizeof(ListenElement));
  neulist->pPerson = p;
  neulist->pnext = 0;
  return neulist;
}



ListenElement* tailsuchen(ListenElement* head)
{
  if(head == 0)
  {
    return head;
  }
  else
  {
    ListenElement* ptail = head;
    while(ptail->pnext != 0)
    {
      ptail = ptail->pnext;
    }
    return ptail;
  }
}



ListenElement* append(ListenElement* head, ListenElement* neulist)
{
  if(head)
  {
    ListenElement* tail = tailsuchen(head);
    tail->pnext = neulist;
    return head;
  }
  else
  {
    neulist->pnext = 0;
    return neulist;
  }
}



void Employeeinfo(Person* p)
{
  printf("\t Name: %s \t \t Abteilung: %c\n", p->name, p->abteilung);
}



void printlist(ListenElement* head)
{
  ListenElement* ptail = head;
  while (ptail != 0)
  {
    Employeeinfo(ptail->pPerson);
    ptail = ptail->pnext;
  }
}



int main()
{
   srand( time(0) ); 
   int Employee =50;
   int Employeeneu = 20;
   ListenElement* Abteilung[26];
   ListenElement* Abteilungneu[5];
   int neuabteilung;
   printf("PPrima Personal:\n");
   
   
   for(int i= 0; i<26; i++)
   {
     Abteilung[i] =0;
   }  
   
   
   for(int i= 0; i<5; i++)
   {
     Abteilungneu[i] =0;
   }
   
   
   for(int j= 0; j < Employee ; j++)
   {
     Person* NewEmployee = newperson();
     int Index = NewEmployee->name[0] -'A';
     Abteilung[Index] = append(Abteilung[Index], createlist(NewEmployee));
   }
   
   for(int k =0; k < 26; k++)
   {
     printf("== Abteilung %c ==\n", k+'A');
     printlist(Abteilung[k]);
   }
   
   printf("\n Firmenumstrukturierung....\n");
   
   
   for(int k =0; k < 26; k++)
   {
     while(Abteilung[k])
     {
       ListenElement* pEmployee = Abteilung[k];
       switch (pEmployee->pPerson->name[1])
       {
       case 'a': 
         neuabteilung =1;
         break;
       case 'e':
         neuabteilung =2 ;
         break;
       case 'i':
         neuabteilung =3 ;
         break;
       case 'o':
         neuabteilung =4 ;
         break;
       case 'u':
         neuabteilung =5 ;
         break;
       }
       Abteilung [k] = pEmployee->pnext;
       pEmployee->pnext= 0;
       pEmployee->pPerson->abteilung = neuabteilung + '1' -1;
       if (Employeeneu)
       {
         Abteilungneu[neuabteilung-1] = append(Abteilungneu[neuabteilung -1], pEmployee);
         Employeeneu--;
       }
       else
       {
         printf("%s muss leider gekuendigt werden.\n", pEmployee->pPerson->name );
         free(pEmployee->pPerson);
         free(pEmployee);
       }
     }
   }
   printf("\n PPrinma Personal nach Umstrukturierung:\n");
   for(int i= 0; i<5; i++)
   {
     printf( "== Abteilung %i ==\n", i+1);
     printlist(Abteilungneu[i]);
   }
   return 0;
}















