#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/
Person* erstelleMitarbeiter()
{
	Person* neuerArbeiter = malloc(sizeof(Person));
	if(neuerArbeiter == NULL) exit(-1);
	
	setRandName(neuerArbeiter->name);
	neuerArbeiter->abteilung = neuerArbeiter->name[0];
	return neuerArbeiter;
}

void append(Person* neuerArbeiter, ListenElement* address)
{
	ListenElement* Dudes = malloc(sizeof(ListenElement));
	if(Dudes == NULL) exit(-1);
	Dudes->pPerson = neuerArbeiter;
	Dudes->pnext = NULL;
	
	if(address->pPerson == NULL) // erstes Element
	{
		address->pPerson = Dudes;
		address->pnext = NULL;
	}
		
	while(address->pnext != NULL) // weitere Elemente
	{
		address = address->pnext;
	}
	address->pnext = Dudes;
	
}

/*---------------------------------------------------------*/

int main()
{
   srand( time(0) ); //initialisiert den zufallszahlengenerator
   
   ListenElement* vulkanausbruchptzwei[26];
   
  for(int i = 0; i <50;i++)
   {
   		 Person* arbeiter = erstelleMitarbeiter();
   		 append(arbeiter, vulkanausbruchptzwei);
   }

   while(vulkanausbruchptzwei[0]->pnext != NULL)
   {
   		printf("Name: %s, Abteilung: %c\n", vulkanausbruchptzwei[0]->pPerson->name, vulkanausbruchptzwei[0]->pPerson->abteilung);
		vulkanausbruchptzwei[0] = vulkanausbruchptzwei[0]->pnext;
   	}
/* 


Honestly, bitte kontrollier diese Hausaufgabe nicht. Ich habe alle anderen gut geschafft, nur diese nicht.  Theoretisch hätte ich diese auch geschafft, aber das array will sich einfach nicht übergeben lassen. (Zeile 100)





*/


}






