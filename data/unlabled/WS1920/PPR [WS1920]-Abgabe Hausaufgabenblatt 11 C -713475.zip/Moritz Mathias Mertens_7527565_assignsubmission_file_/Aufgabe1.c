#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
    char name[11];
    char abteilung;
} Person;

typedef struct listenElement{
    Person* pPerson;
    struct listenElement* pnext;
} ListenElement;

/*---------------------------------------------------------*/

int randAB( int a, int b )
{
    int r = rand() % (b - a + 1);
    return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
    int r = randAB( 1, 5 );
    switch ( r )
    {
        case 1: return 'a';
        case 2: return 'e';
        case 3: return 'i';
        case 4: return 'o';
        case 5: return 'u';
        default: return 'e';
    }
}

char getRandLetter( )
{
    return randAB( 97, 122 );
}

void setRandName( char* pname )
{
    int len = randAB( 3, 10 );
    for ( int i = 0; i < len; i++ )
    {
        if ( i % 2 == 0 ) pname[i] = getRandLetter();
        else pname[i] = getRandVowel(); // every odd letter a vowel
    }
    pname[len] = '\0';
    pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/

Person* newPerson()
{
    Person* pnew=(Person*)malloc(sizeof(Person));
    if(pnew==0)
    {
        exit(-1);
    }
    setRandName(pnew->name);
    pnew->abteilung=pnew->name[0];
    return pnew;
}

ListenElement* newElement(Person* p)
{
    ListenElement* lnew = (ListenElement*)malloc(sizeof(ListenElement));
    if(lnew==0)
    {
        exit(-2);
    }
    lnew->pPerson=p;
    lnew->pnext=0;
    return lnew;
}

ListenElement* lastElement(ListenElement* e)
{
    if (e == 0) return e;
    else
    {
        ListenElement* e1=e;
        while (e1->pnext!=0) e1=e1->pnext;
        return e1;
    }
}

ListenElement* appendElement(ListenElement* e1, ListenElement* pnew)
{
    if (e1)
    {
        ListenElement* pL=lastElement(e1);
        pL->pnext=pnew;
        return e1;
    }
    else
    {
        pnew->pnext=0;
        return pnew;
    }
}

void printPerson(Person* p)
{
    printf( " Name: %s    Abteilung: %c \n", p->name, p->abteilung );
}

void printList(ListenElement* e1)
{
    ListenElement* lnew=e1;
    while(lnew!=0)
    {
        printPerson(lnew->pPerson);
        lnew=lnew->pnext;
    }
}

int main()
{
    srand( time(0) ); //initialisiert den zufallszahlengenerator

    ListenElement* Firma[26]; // Array, der alle Abteilungen der Firma beinhaltet

    for (int i=0; i<26; i++)
    {
        Firma[i]=0;
    }

    for (int i=0; i<50; i++)
    {
        Person* pnew=newPerson();
        int abtNum=pnew->name[0]-65; // ASCII Code Nummer, welche dem ersten Buchstaben des Namens entspricht
        Firma[abtNum]=appendElement(Firma[abtNum],newElement(pnew));
    }

    printf( "PPrima Personal:\n");

    for ( int i=0; i<26; i++)
    {
        printf( "== Abteilung %c ==\n", i+65);
        printList(Firma[i]);
    }


    printf("\nFirmenumstrukturierung...\n");

    int stayEmp=20; // Mitarbeiter, die in der Firma bleiben dürfen
    ListenElement* firmaNew[5]; // nun besteht die Firma nur noch aus 5 Abteilungen

    for (int i=0; i<5; i++)
    {
        firmaNew[i]=0;

    }

    for (int i=0; i<26; i++)
    {
        while (Firma[i])
        {
            ListenElement* pElem=Firma[i];
            int newAbt=1;
            switch (pElem->pPerson->name[1])
            {
                case'a':
                    newAbt=1;
                    break;
                case'e':
                    newAbt=2;
                    break;
                case'i':
                    newAbt=3;
                    break;
                case'o':
                    newAbt=4;
                    break;
                case'u':
                    newAbt=5;
                    break;
            }
            Firma[i]=pElem->pnext;
            pElem->pnext=0;
            pElem->pPerson->abteilung=newAbt+'1'-1;
            if(stayEmp)
            {
                firmaNew[newAbt-1]=appendElement(firmaNew[newAbt-1],pElem);
                stayEmp--;
            }
            else
            {
                printf("%s muss leider gekuendigt werden.\n", pElem->pPerson->name);
                free(pElem->pPerson);
                free(pElem);
            }
        }
    }

    printf("\nPPrima Personal nach Umstrukturierung:\n");



    for (int i=0; i<5; i++)
    {
        printf("== Abteilung %i ==\n", i+1);
        printList(firmaNew[i]);
    }

}