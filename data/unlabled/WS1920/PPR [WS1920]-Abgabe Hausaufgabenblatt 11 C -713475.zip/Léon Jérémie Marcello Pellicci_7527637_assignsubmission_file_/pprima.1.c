#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/








/*---------------------------------------------------------*/

int main()
{
	//initialisiert den zufallszahlengenerator
	srand( time(0) );
	// Abteilungen f�llen 
	Person* worker = (Person*) malloc(sizeof(Person) * 50);
	if(!worker) exit(-1);
	ListenElement* Abteilungen = (ListenElement*) malloc(sizeof(Person) * 26);
	if(!Abteilungen) exit(-1);
	int counter = 0;
	for(int i = 0; i < 50; i++){
		setRandName(worker[i].name);
		worker[i].abteilung = worker[i].name[0];
		printf("Abteilung: %c	Name: %s\n", worker[i].abteilung, worker[i].name);
	}
	for(char i = 'A'; i < 'Z'; i++){
		for(int j = 0; j < 26; j++){
			if(worker[j].name[0] == i){
				counter++;
			}
			Abteilungen[j].pnext = malloc(sizeof(Person) * counter);
		}
		printf("Buchstabe %c ist %d mal vorhanden.\n", i, counter);
		counter = 0;
	}
	for(char i = 'A'; i < 'Z'; i++){
		for(int j = 0; j < 26; j++){
			if(worker[j].name[0] == i){
				Abteilungen[j].pnext->pPerson = worker[j].name;
			}
		}
	}
	// Abteilungen ausgeben
	
	// Mitarbeiter k�ndigen oder in neue Abteilungen verschieben
	for(int i = 0; i < 30; i++){
		for(int j = 0; j < 26; j++){
			if(Abteilungen[i].pnext->pPerson >= 5){
				
			}
		}
	}
	// Neue Abteilungen ausgeben
}
