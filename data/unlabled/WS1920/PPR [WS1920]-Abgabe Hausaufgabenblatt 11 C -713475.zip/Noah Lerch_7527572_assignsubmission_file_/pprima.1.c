#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}
ListenElement* createListenElement(Person* p) {
	ListenElement* pE = (ListenElement*) malloc(sizeof(ListenElement));
	if(pE==NULL) exit(-1);

	pE->pnext = 0;
	pE->pPerson = p;
	return pE;
}

Person* createPerson() {
	Person* p = (Person*) malloc(sizeof(Person));

	if(p == NULL) exit(-1);

	setRandName(p->name);
	p->abteilung = p->name[0];
	
	return p;
}

ListenElement* last(ListenElement* p) {
	if(p == NULL) exit(-1);
	ListenElement* copy = p; 
	while(copy->pnext != 0) copy = copy->pnext;
	return copy;
}

ListenElement* addLast(ListenElement* pA, ListenElement* pN) {
	//WEnn noch kein erstes Da, f�ge das am Anfang ein
	if(pA == 0){
		pN->pnext = 0;
		return pN;
	}
	else {
	last(pA)->pnext = pN;
	return pA;
	}
}


int main()
{
	printf("PPRima Personal : \n");
   srand( time(0) ); //initialisiert den zufallszahlengenerator
   // Abteilungen f�llen 	
	int numberOfCoWorkers = 50;
	ListenElement* abteilung[26];
	for(int i = 0; i < 26; i++) {
		abteilung[i]=0;//Damit darauf zugegriffen werden kann	
	}
   // Abteilungen ausgeben
	for(int i = 0; i < numberOfCoWorkers; i++) {
		Person* p = createPerson();
		int id = p->name[0] - 'A' ; //ERster Buchstabe ist Gross, damit A = 0... Z = 25
		abteilung[id] = addLast(abteilung[id], createListenElement(p));
	}
	for(int i = 0; i < 26; i++) {
		printf("== Abteilung %c == \n", i + 'A');
		ListenElement* copy = abteilung[i];
		while(copy != 0) {
			printf("Name: %s | Abteilung: %c\n", copy->pPerson->name, copy->pPerson->abteilung);
			copy = copy->pnext;
		}
	}
	
   // Mitarbeiter k�ndigen oder in neue Abteilungen verschieben

	printf("\nFirmenumstrukturierung \n");
	int newNumberOfCoWorkers = 20;
	ListenElement* newAbteilung[5];
	for(int i = 0; i < 5; i++) newAbteilung[i] = 0;
	int a = 0;
	for(int i = 0; i < newNumberOfCoWorkers; i++) {
		//Neue Abteilung
		while(abteilung[i]!=0) {
			ListenElement* lE = abteilung[i];
			switch(lE->pPerson->name[1]) {
				case 'a': 
					newAbteilung[0] = addLast(newAbteilung[0], lE);
					lE->pPerson->abteilung = '1';
					break;
				case 'b': 
					newAbteilung[1] = addLast(newAbteilung[1], lE);
					lE->pPerson->abteilung = '2';
					break;
				case 'c': 
					newAbteilung[2] = addLast(newAbteilung[2], lE);
					lE->pPerson->abteilung = '3';
					break;
				case 'd': 
					newAbteilung[3] = addLast(newAbteilung[3], lE);
					lE->pPerson->abteilung = '4';
					break;
				case 'e': 
					newAbteilung[4] = addLast(newAbteilung[4], lE);
					lE->pPerson->abteilung = '5';
					break;
			}
			abteilung[i] = lE->pnext;
			a = i;
		}	
	}
	//Aufnehmen der ersten 20 Leute
	//Wenn die Abteilung beendet war dann n�chste anfangen mit l�schen sonst weiter machen
	int b = 0;
	if(abteilung[a]==0) b = a+1;
	else b = a;
	for(int i = b;i < 26 ; i++) {
		while(abteilung[i]!=0){
		ListenElement* lE = abteilung[i];		
		printf("%s muss leider gehen... \n", lE->pPerson->name);
		free(lE->pPerson);
		free(lE);
		abteilung[i] = lE->pnext;
		}
	}
   // Neue Abteilungen ausgeben
	printf("Neue Firma: \n");
	for(int i = 0; i < 5; i++) {
		printf("Abteilung %i \n",i + 1 );
		ListenElement* copy = newAbteilung[i];
		while(copy != 0) {
			printf("Name: %s | Abteilung: %c\n", copy->pPerson->name, copy->pPerson->abteilung);
			copy = copy->pnext;
		}
		
	}

	

}
