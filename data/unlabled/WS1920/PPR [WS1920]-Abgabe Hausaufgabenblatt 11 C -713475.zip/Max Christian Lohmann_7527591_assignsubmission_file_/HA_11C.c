//
//  main.c
//  HA_11C
//
//  Created by Max Christian Lohmann on 27.01.20.
//  Copyright © 2020 Max Christian Lohmann. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;

/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/
char abteilungszuweisung(char* name)
{
    char nummer;
    nummer = *name;
    return nummer;
}

/*---------------------------------------------------------*/

void zuordnung(ListenElement **listej, char* name, char abteilung)
{
    ListenElement *neu;
    while (*listej != NULL) {
        listej = &(*listej)->pnext;
    }
    neu = (ListenElement*) malloc(sizeof(ListenElement));
    neu->pPerson = (Person*) malloc(sizeof(Person));
    strcpy(neu->pPerson->name, name);
    neu->pPerson->abteilung = abteilung;
    *listej = neu;
}

/*---------------------------------------------------------*/
void printListe(const ListenElement * a)
{
     for( ; a != NULL ; a = a->pnext )
       {
            printf("\n%s\n", a->pPerson->name);
        }}

/*---------------------------------------------------------*/

int main()
{
    ListenElement *array;
    array = (ListenElement*) malloc(26*sizeof(ListenElement));
    if (array == 0) {
        printf("Kein Speicherplatz mehr verfügbar!");
        return 0;
    }
    
    srand((unsigned)time(0) );
    //initialisiert den zufallszahlengenerator
    Person* mitarbeiter;
    mitarbeiter = (Person*) malloc(50 * sizeof(Person));
    for (int i = 0; i < 50; i++) {
        setRandName((*(mitarbeiter + i)).name);
        (*(mitarbeiter + i)).abteilung = abteilungszuweisung((*(mitarbeiter + i)).name);
        int c = i + 1;
        printf("\nAbteilung %c\n%d: %s\n", (*(mitarbeiter + i)).abteilung, c , (*(mitarbeiter + i)).name);
        }
    //Abteilungen erstellen
    
    // Abteilungen füllen
    for (char j = 'A'; j <= 'Z'; j++) {
        char m = j - 'A';
        ListenElement *liste = array + m;
        for (int i = 0; i < 50; i++) {
            if ((mitarbeiter + i)->abteilung == j) {
                zuordnung(&(liste), (*(mitarbeiter + i)).name, (*(mitarbeiter + i)).abteilung);
            }
        }
    }
    // Abteilungen ausgeben
    for (char j = 'A'; j <= 'Z'; j++) {
        printf("\n==Abteilung %c==\n", j);
        char c = j - 'A';
        printListe(array + c);
    }
    // Mitarbeiter kündigen oder in neue Abteilungen verschieben
    // Neue Abteilungen ausgeben
    free(array);
    return 0;
}
