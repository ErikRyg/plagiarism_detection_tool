#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*
Die Hilfsfunktionen für Listenoperationen append und print stammen aus dem Tutorial https://de.wikibooks.org/wiki/C-Programmierung:_Verkettete_Listen
und wurden auf die Aufgabe angepasst
*/


void append(ListenElement **list, Person* p)
{
    ListenElement* neuesElement;
    
    //Ende von Liste suchen, um dort anzufügen
    while( *list != NULL ) 
    {
        list = &(*list)->pnext;
    }

    //neuesElement wird mit zu einfügender Person initalisiert -> das ist das Ende der ursprünglichen Liste
    neuesElement = malloc(sizeof(ListenElement)); 
    neuesElement->pPerson = p;
    neuesElement->pnext = NULL; 

    *list = neuesElement;
}

void printlist(ListenElement* abteilung)
{
    //für abteilung-Liste solange alle Personen-namen ausgeben, bis Ende gefunden wurde
    for( ; abteilung != NULL ; abteilung = abteilung->pnext )
    {
        printf("%s\n", abteilung->pPerson->name);
    }
}

/*---------------------------------------------------------*/

int main()
{
   srand( time(0) ); //initialisiert den zufallszahlengenerator
   //abteilungen initialisieren, anfangszustand
   ListenElement* abteilungen[26];
   for(int i=0; i<26; i++){
       abteilungen[i] = NULL;
   }
   //personen initialisieren, zu abteilung hinzufügen entsprechend Anfangsbuchstaben
   for(int i=0; i<50; i++){
       Person* p = (Person*) malloc(sizeof(Person));
       setRandName(p->name);
       p->abteilung=p->name[0]; //erster buchstabe von person
       int intErsterBuchstabe = p->name[0];
       //a entspricht 65 nach Umwandlung zu einem int, daher 65 abziehen für index 0, usw
       append(&abteilungen[intErsterBuchstabe-65], p);
   }
   //für alle erstellten Abteilungen die Personen ausgeben
   for(int i=0; i<26; i++){
       char current = i+65;
       printf("Abteilung %c \n", current);
       printlist(abteilungen[i]);
   }
   //neue Abteilungen erstellen
    ListenElement* neueAbteilungen[5];
    for(int i=0; i<5; i++){
       neueAbteilungen[i] = NULL;
   }
   //neue Abteilungen mit Personen befüllen, solange bis 20 erreicht sind (counter als orientierung)
   int counter = 0;
   for(int i=0; i<26; i++){
       for( ; abteilungen[i] != NULL ; abteilungen[i] = abteilungen[i]->pnext )
    {
        if(counter==20){
            break;
        }
        if(abteilungen[i]->pPerson->name[1] == 'a'){
            abteilungen[i]->pPerson->abteilung='1';
            append(&neueAbteilungen[0], abteilungen[i]->pPerson);
        }else if(abteilungen[i]->pPerson->name[1] == 'e'){
            abteilungen[i]->pPerson->abteilung='2';
            append(&neueAbteilungen[1], abteilungen[i]->pPerson);
        }else if(abteilungen[i]->pPerson->name[1] == 'i'){
            abteilungen[i]->pPerson->abteilung='3';
            append(&neueAbteilungen[2], abteilungen[i]->pPerson);
        }else if(abteilungen[i]->pPerson->name[1] == 'o'){
            abteilungen[i]->pPerson->abteilung='4';
            append(&neueAbteilungen[3], abteilungen[i]->pPerson);
        }else{
            abteilungen[i]->pPerson->abteilung='5';
            append(&neueAbteilungen[4], abteilungen[i]->pPerson);
        }
        counter++;
    }
   }
   printf("\n\n\n");
    //für alle neu erstellten Abteilungen die Personen ausgeben
   for(int i=0; i<5; i++){
       printf("Abteilung %d \n", i+1);
       printlist(neueAbteilungen[i]);
   }
}