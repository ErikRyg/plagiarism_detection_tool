#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/
void appendElement(ListenElement* liste, ListenElement* pNeu)
{
   ListenElement* pNeuesElement=(ListenElement*)malloc(sizeof(ListenElement));
   pNeuesElement=pNeu;
   ListenElement* p=liste;
   for(;p->pnext!=0;p->pPerson=p->pnext)
      {
      p->pnext=&pNeuesElement;
      }



}
/*---------------------------------------------------------*/

int main()
{
   srand( time(0) ); //initialisiert den zufallszahlengenerator
   Person Mitarbeiter[49];
   ListenElement Abteilung[25];
   for(int i=0;i<50;i++) // Abteilungen f�llen, Namen generieren
      { 
      setRandName(&Mitarbeiter[i].name[0]);                  
      Mitarbeiter[i].abteilung=Mitarbeiter[i].name[0];
      for(int k=0;k<26;k++)
         {
         if(k==(int)Mitarbeiter[i].abteilung-65)
           {
           appendElement(&Abteilung[k],&Mitarbeiter[i]);
           }
         }
      }
   for(int i=0;i<50;i++)
      {
      printf("Name: %s Abteilung: %c\n",Mitarbeiter[i].name,Mitarbeiter[i].abteilung);
      }
   for(int i=0;i<26;i++)// Abteilungen ausgeben
      {
      printf("== Abteilung == %c\n",i+65);
      while(Abteilung[i].pnext!=NULL)
           {
           printf("Name: %s Abteilung: %c\n",Abteilung[i].pPerson->name,Abteilung[i].pPerson->abteilung);
           Abteilung[i].pPerson=Abteilung[i].pnext;
           }
      }
   // Mitarbeiter k�ndigen oder in neue Abteilungen verschieben
   // Neue Abteilungen ausgeben
}
