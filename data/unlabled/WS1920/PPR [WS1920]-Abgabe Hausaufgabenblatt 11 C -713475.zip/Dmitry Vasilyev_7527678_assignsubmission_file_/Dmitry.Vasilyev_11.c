#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
/*---------------------------------------------------------*/
typedef struct listenAbteilung{
    ListenElement *pListenElement;
    char Abteilung;
    struct listenAbteilung* pnext;

}ListenAbteilung;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/
void *MemoryCheck (size_t Groesse) {
  void *Memory = malloc (Groesse);
  if (Memory == NULL) {
    printf ("Kein Speicher.\n");
    exit (1);
  }
  return Memory;
}

void addAbteilung(ListenAbteilung** pAbteilung, char *ch)   
{
  ListenAbteilung* NewAbteilung=MemoryCheck(sizeof(*NewAbteilung));
  NewAbteilung->pnext=NULL;
  NewAbteilung->Abteilung=*ch;
  ListenAbteilung* last =* pAbteilung; 
  if (*pAbteilung==NULL)
  {
    *pAbteilung=NewAbteilung;
    return;
  }
  while (last->pnext != NULL) 
    last = last->pnext; 
    last->pnext = NewAbteilung; 
}

void addElement(ListenAbteilung* pAbteilung, Person *NewPerson)
{
  ListenElement* NewElement=MemoryCheck(sizeof(*NewElement));//
  NewElement->pnext=NULL;
  NewElement->pPerson=NewPerson;//
  ListenElement* last=pAbteilung->pListenElement;
  if (pAbteilung->pListenElement==NULL)
  {
    pAbteilung->pListenElement=NewElement;
    return;
  }
  while (last->pnext !=NULL)
    last=last->pnext;
  last->pnext=NewElement;
}

Person* createPerson (int i)
{
    Person* NewPerson;
    NewPerson=MemoryCheck(sizeof(*NewPerson));
    setRandName(NewPerson->name);
    NewPerson->abteilung=NewPerson->name[i];
    return NewPerson;
}

void zuordnenPerson (ListenAbteilung* pAbteilung, int Position)
{ 
  for (int i=0; i<50; i++)
  {   
    ListenAbteilung* currAbt = pAbteilung;
    Person* pPerson=createPerson (Position);
    while(currAbt!=NULL)
    { 
      if (pPerson->abteilung == currAbt->Abteilung)
      { 
        addElement(currAbt, pPerson); 
      }
      currAbt=currAbt->pnext;
    }
  }
}

void printPerson(Person* pPerson)
{
  printf("\tName: %s Abt: %c\n", pPerson->name, pPerson->abteilung);
}

void printPerson2(Person* pPerson)
{
  printf("\tName: %s Abt: %i\n", pPerson->name, pPerson->abteilung);
}

void printAll(ListenAbteilung* pAbteilung)
{
  ListenAbteilung* currAbt;
  ListenElement* currElem;
  currAbt = pAbteilung;
  while (currAbt != NULL)
  { 
    printf("== Abteilung %c ==\n", currAbt->Abteilung);
    currElem=currAbt->pListenElement;
    while(currElem != NULL)
    {
      printPerson(currElem->pPerson);
      currElem=currElem->pnext;
    }
    currAbt=currAbt->pnext;
  }
}

void printAll2(ListenAbteilung* pAbteilung)
{
  ListenAbteilung* currAbt;
  ListenElement* currElem;
  currAbt = pAbteilung;
  while (currAbt != NULL)
  { 
    printf("== Abteilung %d ==\n", currAbt->Abteilung);
    currElem=currAbt->pListenElement;
    while(currElem != NULL)
    {
      printPerson2(currElem->pPerson);
      currElem=currElem->pnext;
    }
    currAbt=currAbt->pnext;
  }
}

void kuendigenPerson(ListenAbteilung **pAbteilung)  //, int max)
{
  int countDel=0;
  int randAbtelungN;
  int AbtN;
  ListenAbteilung* currAbt;
  ListenElement* currElem;
  while(countDel<30)
  { 
    currAbt = *pAbteilung;
    AbtN=0;
    randAbtelungN=randAB(0, 25);
    while (AbtN<=randAbtelungN) 
    {
      if (AbtN==randAbtelungN)
      {
        currElem=currAbt->pListenElement;
        if (currElem==NULL)
        {
          break;
        }
        printPerson(currElem->pPerson);
        currAbt->pListenElement =currElem->pnext;
        free(currElem);
        countDel++;
      }
      AbtN++;
      currAbt=currAbt->pnext;
    }
  }
}

void addAbteilung2(ListenAbteilung** pAbteilung, int *Number)
{
  ListenAbteilung* NewAbteilung=MemoryCheck(sizeof(*NewAbteilung));
  NewAbteilung->pnext=NULL;
  NewAbteilung->Abteilung=*Number;
  ListenAbteilung* last =* pAbteilung; 
  if (*pAbteilung==NULL)
  {
    *pAbteilung=NewAbteilung;
    return;
  }
  while (last->pnext != NULL) 
    last = last->pnext; 
    last->pnext = NewAbteilung; 
}

void zuordnenPerson2 (ListenAbteilung* pAbteilung, ListenAbteilung* pAbteilung2, int Position)
{ 
  ListenAbteilung* currAbt = pAbteilung;
  char ch;
  int AbteilungNumber;
  while(currAbt!=NULL)
  { 
    ListenElement *currElem=currAbt->pListenElement;
    while(currElem!=NULL)
    {
      ch=currElem->pPerson->name[1];
      switch(ch){
        case 'a': AbteilungNumber=1;
          break;
        case 'e': AbteilungNumber=2;
          break;
        case 'i': AbteilungNumber=3;
          break;  
        case 'o': AbteilungNumber=4;
          break;
        case 'u': AbteilungNumber=5;
          break;  
      }
      currElem->pPerson->abteilung=AbteilungNumber;       
      ListenAbteilung* currAbt2=pAbteilung2;
      while(currAbt2!=NULL)
      {
        ListenElement* currElem2=pAbteilung2->pListenElement;
        {
          if(AbteilungNumber==currAbt2->Abteilung)
          {
          addElement(currAbt2, currElem->pPerson); 
          }
        }
        currAbt2=currAbt2->pnext;
      }
      free(currElem);
      currElem=currElem->pnext;
    }
    free(currAbt);
    currAbt=currAbt->pnext;
  }  
}

/*---------------------------------------------------------*/
int main()
{
  srand( time(0) ); //initialisiert den zufallszahlengenerator
  // Abteilungen füllen
  int Position=0;
  ListenAbteilung* pAbteilung;
  pAbteilung=NULL;
  ListenAbteilung* pAbteilung2;
  pAbteilung2=NULL;
  for (char ch='A'; ch<='Z'; ch++)
  {
    addAbteilung(&pAbteilung,&ch);
  }
  zuordnenPerson(pAbteilung,Position);
  // Abteilungen ausgeben
  printf("\n\nPPrima Personal\n\n");
  printAll(pAbteilung);
   // Mitarbeiter kündigen oder in neue Abteilungen verschieben
        //Rand Abteilung von A bis Z /
  printf("\n\n== Firmenumstrukturierung ==\n\n");
  printf("Personen, die leider gekuendigt werden muessen:\n");
  kuendigenPerson(&pAbteilung);//, max);      
  printf("\n\nPPrima Personal nach Umstrukturierung\n\n");
  for (int i=1; i<=5;i++)
  {
    addAbteilung2(&pAbteilung2,&i);
  }
    Position=1;
    zuordnenPerson2(pAbteilung, pAbteilung2, Position);
    //Neue Abteilungen ausgeben

    printAll2(pAbteilung2);

}
