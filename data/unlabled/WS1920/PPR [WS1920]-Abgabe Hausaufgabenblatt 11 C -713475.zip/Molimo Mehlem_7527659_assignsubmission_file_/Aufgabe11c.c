#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB( 97, 122 );
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

/*---------------------------------------------------------*/








/*---------------------------------------------------------*/

int main()
{
   srand( time(0) ); //initialisiert den zufallszahlengenerator
   ListenElement liste[26];
   Person* tmp;
   for(int k = 0;k<26;k++)
   {
       liste[k].pPerson=malloc(sizeof(Person));
   }
   for(int i = 0;i<50;i++)
   {
       setRandName(tmp->name);
       if(tmp->name[0]='A'){liste[0].pPerson=realloc(liste[0].pPerson,sizeof(liste[0].pPerson)+sizeof(Person));tmp->abteilung='A'; liste[0].pPerson=tmp;}
       else if(tmp->name[0]='B'){liste[1].pPerson=realloc(liste[1].pPerson,sizeof(liste[1].pPerson)+sizeof(Person));
	tmp->abteilung='B'; liste[1].pPerson=tmp;}
       else if(tmp->name[0]='C'){liste[2].pPerson=realloc(liste[2].pPerson,sizeof(liste[2].pPerson)+sizeof(Person));
	tmp->abteilung='C'; liste[2].pPerson=tmp;}
       else if(tmp->name[0]='D'){liste[3].pPerson=realloc(liste[3].pPerson,sizeof(liste[3].pPerson)+sizeof(Person));
	tmp->abteilung='D'; liste[3].pPerson=tmp;}
       else if(tmp->name[0]='E'){liste[4].pPerson=realloc(liste[4].pPerson,sizeof(liste[4].pPerson)+sizeof(Person));tmp->abteilung='E';
	 liste[4].pPerson=tmp;}
       else if(tmp->name[0]='F'){liste[5].pPerson=realloc(liste[5].pPerson,sizeof(liste[5].pPerson)+sizeof(Person));tmp->abteilung='F'; 
	liste[5].pPerson=tmp;}
       else if(tmp->name[0]='G'){liste[6].pPerson=realloc(liste[6].pPerson,sizeof(liste[6].pPerson)+sizeof(Person));tmp->abteilung='G';
	 liste[6].pPerson=tmp;}
       else if(tmp->name[0]='H'){liste[7].pPerson=realloc(liste[7].pPerson,sizeof(liste[7].pPerson)+sizeof(Person));tmp->abteilung='H';
	 liste[7].pPerson=tmp;}
       else if(tmp->name[0]='I'){liste[8].pPerson=realloc(liste[8].pPerson,sizeof(liste[8].pPerson)+sizeof(Person));tmp->abteilung='I'; 
	liste[8].pPerson=tmp;}
       else if(tmp->name[0]='J'){liste[9].pPerson=realloc(liste[9].pPerson,sizeof(liste[9].pPerson)+sizeof(Person));tmp->abteilung='J'; 
	liste[9].pPerson=tmp;}
       else if(tmp->name[0]='K'){liste[10].pPerson=realloc(liste[10].pPerson,sizeof(liste[10].pPerson)+sizeof(Person));tmp->abteilung='K'; 
	liste[10].pPerson=tmp;}
       else if(tmp->name[0]='L'){liste[11].pPerson=realloc(liste[11].pPerson,sizeof(liste[11].pPerson)+sizeof(Person));tmp->abteilung='L'; 
	liste[11].pPerson=tmp;}
       else if(tmp->name[0]='M'){liste[12].pPerson=realloc(liste[12].pPerson,sizeof(liste[12].pPerson)+sizeof(Person));tmp->abteilung='M'; 
	liste[12].pPerson=tmp;}
       else if(tmp->name[0]='N'){liste[13].pPerson=realloc(liste[13].pPerson,sizeof(liste[13].pPerson)+sizeof(Person));tmp->abteilung='N'; 
	liste[13].pPerson=tmp;}
       else if(tmp->name[0]='O'){liste[14].pPerson=realloc(liste[14].pPerson,sizeof(liste[14].pPerson)+sizeof(Person));tmp->abteilung='O'; 
	liste[14].pPerson=tmp;}
       else if(tmp->name[0]='P'){liste[15].pPerson=realloc(liste[15].pPerson,sizeof(liste[15].pPerson)+sizeof(Person));tmp->abteilung='P'; 
	liste[15].pPerson=tmp;}
       else if(tmp->name[0]='Q'){liste[16].pPerson=realloc(liste[16].pPerson,sizeof(liste[16].pPerson)+sizeof(Person));tmp->abteilung='Q'; 
	liste[16].pPerson=tmp;}
       else if(tmp->name[0]='R'){liste[17].pPerson=realloc(liste[17].pPerson,sizeof(liste[17].pPerson)+sizeof(Person));tmp->abteilung='R'; 
	liste[17].pPerson=tmp;}
       else if(tmp->name[0]='S'){liste[18].pPerson=realloc(liste[18].pPerson,sizeof(liste[18].pPerson)+sizeof(Person));tmp->abteilung='S'; 
	liste[18].pPerson=tmp;}
       else if(tmp->name[0]='T'){liste[19].pPerson=realloc(liste[19].pPerson,sizeof(liste[19].pPerson)+sizeof(Person));tmp->abteilung='T'; 
	liste[19].pPerson=tmp;}
       else if(tmp->name[0]='U'){liste[20].pPerson=realloc(liste[20].pPerson,sizeof(liste[20].pPerson)+sizeof(Person));tmp->abteilung='U'; 
	liste[20].pPerson=tmp;}
       else if(tmp->name[0]='V'){liste[21].pPerson=realloc(liste[21].pPerson,sizeof(liste[21].pPerson)+sizeof(Person));tmp->abteilung='V'; 
	liste[21].pPerson=tmp;}
       else if(tmp->name[0]='W'){liste[22].pPerson=realloc(liste[22].pPerson,sizeof(liste[22].pPerson)+sizeof(Person));tmp->abteilung='W'; 
	liste[22].pPerson=tmp;}
       else if(tmp->name[0]='X'){liste[23].pPerson=realloc(liste[23].pPerson,sizeof(liste[23].pPerson)+sizeof(Person));tmp->abteilung='X'; 
	liste[23].pPerson=tmp;}
       else if(tmp->name[0]='Y'){liste[24].pPerson=realloc(liste[24].pPerson,sizeof(liste[24].pPerson)+sizeof(Person));tmp->abteilung='Y'; 
	liste[24].pPerson=tmp;}
       else if(tmp->name[0]='Z'){liste[25].pPerson=realloc(liste[25].pPerson,sizeof(liste[25].pPerson)+sizeof(Person));tmp->abteilung='Z'; 
	liste[25].pPerson=tmp;}
       
       
   }
   for(int j = 0;j<26;j++)
   {
       printf("Abteilung %i",j+1);
       printf("%s Abteilung%d",liste[j].pPerson->name,liste[j].pPerson->abteilung);
   }
   
   // Abteilungen füllen 
   // Abteilungen ausgeben
   // Mitarbeiter kündigen oder in neue Abteilungen verschieben
   // Neue Abteilungen ausgeben
}

