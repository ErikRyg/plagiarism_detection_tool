#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> //fuer srand init

/*---------------------------------------------------------*/
typedef struct person{
   char name[11];
   char abteilung;
} Person;
 
typedef struct listenElement{
   Person* pPerson;
   struct listenElement* pnext;
} ListenElement;
 
/*---------------------------------------------------------*/

int randAB( int a, int b )
{
  int r = rand() % (b - a + 1);
  return r + a;
}

/*---------------------------------------------------------*/
char getRandVowel( )
{
  int r = randAB( 1, 5 );
  switch ( r )
  {
    case 1: return 'a';
    case 2: return 'e';
    case 3: return 'i';
    case 4: return 'o';
    case 5: return 'u';
    default: return 'e';
  }
}

char getRandLetter( )
{
  return randAB(97, 122);
}

void setRandName( char* pname )
{
  int len = randAB( 3, 10 );
  for ( int i = 0; i < len; i++ )
  {
    if ( i % 2 == 0 ) pname[i] = getRandLetter();
    else pname[i] = getRandVowel(); // every odd letter a vowel
  }
  pname[len] = '\0';
  pname[0] -= 32; // make first letter uppercase
}

void setNewAbteilung(char* pname,char* pabteilung){
  char secondletter = *(pname+1);
  switch ( secondletter )
  {
    case 'a': *pabteilung =1 ;
    case 'e': *pabteilung =2  ;
    case 'i': *pabteilung =3  ;
    case 'o': *pabteilung =4  ;
    case 'u': *pabteilung =5  ;
  }
}
void AbteilungenFuellen(Person* Mitarbeiter, ListenElement* Abteilungen, ListenElement* liste,int n, int nAbt){
    Person* p;
    for(int i =0; i<n;i++){
     p = Mitarbeiter+i;
     
     if(nAbt ==26) {
         setRandName(p->name);
         p->abteilung = *(p->name);
         (liste+i)->pPerson = p;
     }
     else{
         setNewAbteilung(p->name, &(p->abteilung));
     } 
     
     for(int j =0; j<nAbt;j++){
         char aktuellA;
         if(nAbt ==26) aktuellA = 'A'+j;
         else if(nAbt ==5) aktuellA = j+1;
         if(p->abteilung == aktuellA){
                 ListenElement* ptr = Abteilungen+j;
                 while(ptr->pnext !=0){
                     ptr = ptr->pnext;
                 }
                 ptr->pnext =liste+i;
                break;
         }
     }
    }
    ListenElement* temp;
    //Abteilungen ausgeben
    for(int k =0; k<nAbt;k++){
        char aktuellA;
        if(nAbt =26) aktuellA = 'A'+k;
        else if(nAbt =5) aktuellA = k+1;
        temp = (Abteilungen+k)->pnext;
        printf("-------Abteilung %c--------\n", aktuellA);
        while(temp !=0){
            Person currentP = *(temp->pPerson);
            printf("Name: %s, Abteilung: %c\n",(currentP.name),(currentP.abteilung));
            temp =temp->pnext;
        }
    }
}

int main()
{
   srand( time(0) ); //initialisiert den zufallszahlengenerator
   int n=50;
   Person* Mitarbeiter = malloc(sizeof(Person)*n);
   ListenElement* Abteilungen = malloc(sizeof(ListenElement)*26);
   ListenElement* liste =malloc(sizeof(ListenElement)*n);
   // Abteilungen f�llen und ausgeben
   AbteilungenFuellen(Mitarbeiter,Abteilungen,liste,n,26);
   //kuendigen der letzten 30 Mitarbeiter
    printf("\n Kuendigungen: \n");
    for(int i=20;i<n;i++){
        printf("%s muss leider gekuendigt werden.\n",(Mitarbeiter+i)->name);
    }
    Mitarbeiter = realloc(Mitarbeiter, sizeof(Person)*20);
    liste = realloc(liste,sizeof(ListenElement)*20);
    Abteilungen = realloc(Abteilungen, sizeof(ListenElement)*5);
    //neue Abteilungen fuellen und ausgeben
    AbteilungenFuellen(Mitarbeiter,Abteilungen,liste,20,5);
    
    free(Mitarbeiter);
    free(Abteilungen);
    free(liste);
}
