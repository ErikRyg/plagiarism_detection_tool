#include <stdio.h>

int main (){
	int zehnZahlen[10];
	
	for (int i = 1; i<11; i++){
		printf("Gib mir Zahl %i von 10!\n",i);
		scanf("%i", &zehnZahlen[i]);
	}
	printf ("Deine Zahlen ist umgekehrter Reihenfolge sind:\n");
	
	for (int b = 10;b>0;b--){
		printf(" %i ",zehnZahlen[b]);
		
	}
	
	int* p_zahlen = &zehnZahlen[1];
	
	printf ("Die Speicheradresse des Arrays ist %i.\n",p_zahlen);
	printf("Deine letzte Zahl ist %i.\n",zehnZahlen[10]);
	
	p_zahlen = &zehnZahlen[10]+4;
	
	printf("Die Adresse der ersten Speicherzelle hinter dem Array ist %i .\n",p_zahlen);
	
	int* p_zahlen1  = &zehnZahlen[10];
	int* p_zahlen2 = &zehnZahlen[9];
	
	*p_zahlen = p_zahlen1 - p_zahlen2;
	
	printf ("Die Differenz zweier benachbarter Adressen ist: %i\n",p_zahlen);
	
	int belegt = 0;
	
	for(int a = 1; a<11; a++){
		if (zehnZahlen[a] != 0) belegt++;
	}
	
	printf ("Es sind %i Speicherzellen belegt.\n",belegt);
	
	return 0;
}